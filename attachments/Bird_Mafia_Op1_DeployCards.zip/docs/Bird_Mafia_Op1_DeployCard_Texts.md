# Bird Mafia Madness — Op 1 Deploy Card Texts
# Stamped 2026-10-11. Honey Bun = entry narrative. Level desc = unique scenery. Objective = seed + power + how through.
# Seeds follow live SLOT_SEEDS mapped to nicknames. 5-7 word effect wraps to 2 lines on card.

## L1 Desert Briefing — Crimson Hex Seed / Soul Stabilizer
**Honey Bun:** Oof. After all that running you fell through a hole. That must've hurt lol.
**Level desc:** Open neon dunes with a collapsing path. The shaft at the end is the door down.
**Objective:** Grab the Crimson Hex Seed for extra health. Dash the canyon and watch for holes that drop the floor.

## L2 Neon Caves — Cyan Hex Seed / Fuel Efficiency
**Honey Bun:** Ew. That cave was pretty dark and nasty, I wouldn't want to be there. Good thing you got launched hundreds of feet in air like a bird haha!
**Level desc:** Sealed neon cave with glowing veins. A single spring lifts you to the sky lip.
**Objective:** Grab the Cyan Hex Seed to lean stamina drain. Sneak the tunnel and find the spring that launches you out.

## L3 Sky Bridges — Azure Hex Seed / Tenacity Tuning
**Honey Bun:** Whoa. You guys weren't even scared of being inches away from a long fall down. And then you broke the bridge, nice move lol.
**Level desc:** Neon rails arc over a spike gorge. The shot bridge sits in the middle and will break under you.
**Objective:** Grab the Azure Hex Seed for max stamina. Jump the sky rails carefully and find the way down when the bridge collapses.

## L4 Spike Gorge — Magenta Hex Seed / Force-Field Fortify
**Honey Bun:** Yikes. You just slid right into a gorge full of needles. Hope those belts get you out before something sticks lol.
**Level desc:** Needle-filled gorge under the broken span. Belts climb the far wall out of the spikes.
**Objective:** Grab the Magenta Hex Seed for longer shield time. Survive the drop and ride the belts up before the needles catch you.

## L5 Belt Run — Lime Hex Seed / Flux Fixer
**Honey Bun:** Haha. Those belts yanked you straight into the storm. Bet the seed wall at the end looks real friendly right now lol.
**Level desc:** Storm-lashed belt run ending in a wall of giant broken seeds. The tube is the way up.
**Objective:** Grab the Lime Hex Seed for wider magnet range. Ride the belts through the dust and find the tube past the seed wall.

## L6 Vertical Ascent — Violet Hex Seed / Ammo Augment
**Honey Bun:** Gross. You climbed all the way up into that giant seed silo. The flock up there is gonna be thrilled to see you lol.
**Level desc:** Narrow climb tube rising to a seed sewage silo. The cage door is the exit after the flock.
**Objective:** Grab the Violet Hex Seed for faster bullets. Climb the tube, clear the flock, and take the door out of the silo.

## L7 Vertical Descent — Amber Hex Seed / Blaster Buff
**Honey Bun:** Oof. The cage door just dumped you onto that long wall. Those shock lines look like they missed you on purpose haha.
**Level desc:** Giant bird-cage wall with shock lines below. Optional cages sit on the descent.
**Objective:** Grab the Amber Hex Seed for damage boost. Step out of the door, shoot the cages if you want, and ride the lines down.

## L8 Hardpan — Chartreuse Hex Seed / Mag Multiplier
**Honey Bun:** Whoa. You jumped onto those power lines like they weren't trying to zap you. One miss and you're toast lol.
**Level desc:** Horizontal telephone poles with drooping wires. The factory is only the background.
**Objective:** Grab the Chartreuse Hex Seed for more max ammo. Jump pole to pole and keep your feet off the shocks.

## L9 Mafia Approach — Fuchsia Hex Seed / Armor Amplifier
**Honey Bun:** Heh. All that running and you still ended up on an endless plateau. Don Corvone is already waiting at the far end lol.
**Level desc:** Endless magenta plateau with no castle. Don Corvone arrives at the far ridge and does not fight.
**Objective:** Grab the Fuchsia Hex Seed for damage reduction. Walk the plateau, take the early seed, and reach the ridge where Don opens Level 10.

## L10 Don Corvone — Indigo Hex Seed / (leftover / Neon check)
**Honey Bun:** Nice. You made it all the way to Don Corvone. Too bad I wasn't there lol. Get back to the van and come save me!
**Level desc:** Boss arena under Don’s perch. Three phases: floor, tiers, then the extract.
**Objective:** Grab the Neon Chaos Seed if the nine Hex are collected. Survive the phases and take the extract.

## Card notes
- Purple section stays 3-line seed stack (name / nick / 5-7 word effect that wraps to 2 lines). No “Hunt”.
- Radio = Honey Bun entry line above.
- Level flavor = scenery line.
- Objective = seed + power + path line.
- L3 HTML already stamped with these texts.
