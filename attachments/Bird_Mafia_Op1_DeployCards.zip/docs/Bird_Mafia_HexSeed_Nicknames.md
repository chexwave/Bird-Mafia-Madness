# Bird Mafia Madness — Hex Seed Nickname + Effect Update
# For packaging with the Build Mode handoff.
# User-adjusted power-ups 2026-10-11. Effect descriptions tuned to 5-7 words so they wrap to exactly two lines on the card.

## Proposed Hex Seed mapping (9 permanent)

| Slot | Hex Name              | Nickname            | Short Effect          | 5-7 Word Description (wraps to 2 lines)          |
|------|-----------------------|---------------------|-----------------------|--------------------------------------------------|
| 1    | Crimson Hex Seed      | Soul Stabilizer     | +5 max Health         | Permanently adds five max health points.         |
| 2    | Amber Hex Seed        | Blaster Buff        | Damage boost          | Raises damage so shots hit harder.               |
| 3    | Chartreuse Hex Seed   | Mag Multiplier      | + max Ammo            | Increases max ammo for longer fights.            |
| 4    | Lime Hex Seed         | Flux Fixer          | Pickup magnet range   | Extends magnet range for closer pickups.         |
| 5    | Viridian Hex Seed     | Armor Amplifier     | Damage reduction      | Reduces incoming damage from bird hits.          |
| 6    | Cyan Hex Seed         | Fuel Efficiency     | Stamina lean          | Leans stamina drain for farther runs.            |
| 7    | Azure Hex Seed        | Tenacity Tuning     | + max Stamina         | Boosts max stamina for longer chases.            |
| 8    | Indigo Hex Seed       | Ammo Augment        | Faster bullets        | Speeds bullet travel to the flock.               |
| 9    | Fuchsia Hex Seed      | Force-Field Fortify | Max shield time       | Extends shield time so it holds longer.          |

Notes:
- Viridian glow brighter, Lime greener (from prior lock).
- Neon Chaos Seed remains holographic crystal, conditional L10 amp.
- Nicknames go on the deploy card as the middle line.
- Effect description is sized to wrap cleanly to two lines (not one, not three).
- Radio / HUD / chaosBeat update to “Hex Seed” + nickname where space allows.
- Objective still calls out the power surge separately.

## Deploy card purple section (no “Hunt”)

Three lines (desc wraps to two):

Azure Hex Seed

Tenacity Tuning

Boosts max stamina for longer chases.

(Icons stay: power left, seed right. Center is the seed stack.)

## Next

Drop updated card HTML into the design set.
Include this table in the next Build Mode paste with the HexNeon handoff.
